#include <stdio.h>
#include <awdrm.h>
FILE *	aw_fopen(char *filename, char *mode)
{
	return fopen(filename, mode);
}

int aw_fclose(FILE *fp)
{
	return fclose(fp);
}

int aw_fseek(FILE *fp, long offset, int origin)
{
	return fseek(fp, offset, origin);
}

int aw_fread(void *buf, int size, int count, FILE *fp)
{
	return fread(buf, size, count, fp);
}

long aw_ftell(FILE *fp)
{
	return ftell(fp);
}

int  aw_fwrite(void *buf, int size, int count, FILE *fp)
{
	return fwrite(buf, size, count, fp);
}

int aw_fllseek(FILE * fp, long long Offset, int Whence)
{
	return fseeko(fp, Offset, Whence);
}

long long aw_flltell(FILE * stream)
{
	return ftello(stream);
}











//below code may no use for release, it's just for dll reference.

FILE* swdrm_fopen(char*filename,char*mode)
{
	return awdrm_fopen(filename, mode);
}

int swdrm_fclose(FILE*fp)
{
	return awdrm_fclose(fp);
}

int swdrm_ftell(FILE *fp)
{
	return awdrm_ftell(fp);
}


long long swdrm_flltell(FILE *fp) {
	return awdrm_flltell(fp);
}

int swdrm_fseek(FILE*fp, long offset,int base)
{
	return awdrm_fseek(fp,offset,base);
}

int swdrm_fllseek(FILE*fp, long long offset,int base)
{
	return awdrm_fllseek(fp,offset,base);
}

int swdrm_fread(char *pt, unsigned size,unsigned n,FILE *fp)
{
	return awdrm_fread(pt,  size, n,fp);
}

int swdrm_getadd(FILE*fp, char* addstream)
{
	return awdrm_getadd(fp, addstream);
}

int swdrm_getaddlen(FILE*fp)
{
	return awdrm_getaddlen(fp);
}

