/******************************************************************************
--                                                                            --
--                    CedarX Multimedia Framework                             --
--                                                                            --
--          the Multimedia Framework for Linux/Android System                 --
--                                                                            --
--       This software is confidential and proprietary and may be used        --
--        only as expressly authorized by a licensing agreement from          --
--                         Softwinner Products.                               --
--                                                                            --
--                   (C) COPYRIGHT 2011 SOFTWINNER PRODUCTS                   --
--                            ALL RIGHTS RESERVED                             --
--                                                                            --
--                 The entire notice above must be reproduced                 --
--                  on all copies and should not be removed.                  --
--                                                                            --
*******************************************************************************/

//#define LOG_NDEBUG 0
#define LOG_TAG "sft_httplive_stream_wrapper"
#include <CDX_Debug.h>

#include <cedarx_stream.h>
#include <cedarx_demux.h>

#include <LiveDataSource.h>
//#include <LiveSession.h>

#include <media/stagefright/foundation/ABuffer.h>
#include <media/stagefright/foundation/ADebug.h>
#include <media/stagefright/foundation/AMessage.h>
#include <media/stagefright/foundation/ALooper.h>
#include <media/stagefright/MediaErrors.h>
#include <media/stagefright/MetaData.h>

//TODO: 1. lock/unlock 2.memory leak 3.memory efficient 4.cache parameter adjust
//5.free page/active page 7.external exit to abort read 8.qiyi total time

namespace android
{
	typedef struct M3U8_CONTEXT
	{
		sp<ALooper>     mLiveLooper;
		sp<LiveSession> mLiveSession;
		int             mForceExit;
		void * 			mDataSource;
	}m3u8_ctx_t;

	extern "C" {

	#define HTTP_LIVE_TS_PACKET_SIZE	188
	#define MAX_READ_TRY_COUNT			800

		void* HTTPLiveSourceOpen(CedarXDataSourceDesc *datasrc_desc)
		{
			int             err;
			m3u8_ctx_t*     m3u8_context;
			pthread_mutex_lock(&datasrc_desc->m3u_handle_mutex);
			m3u8_context = new m3u8_ctx_t;
			datasrc_desc->m3u_handle = m3u8_context;
			LOGD("datasrc_desc->m3u_handle %p, datasrc_desc %p", datasrc_desc->m3u_handle, datasrc_desc);
			if(m3u8_context != NULL)
			{
				m3u8_context->mDataSource = (void *)datasrc_desc;
				m3u8_context->mLiveLooper = new ALooper;
				m3u8_context->mLiveLooper->setName("http live");
				m3u8_context->mLiveLooper->start();

				m3u8_context->mLiveSession = new LiveSession(0, 0, 0);
				pthread_mutex_unlock(&datasrc_desc->m3u_handle_mutex);
				m3u8_context->mLiveLooper->registerHandler(m3u8_context->mLiveSession);
				m3u8_context->mLiveSession->connect(datasrc_desc->source_url, NULL);

				m3u8_context->mForceExit = 0;
			}
			else
			{
				pthread_mutex_unlock(&datasrc_desc->m3u_handle_mutex);
			}

			return (void*)m3u8_context;
		}

		void HTTPLiveSourceClose(void* m3u8_context)
		{
			m3u8_ctx_t* ctx;
			ctx = (m3u8_ctx_t*)m3u8_context;
			if(ctx == NULL)
				return;
			LOGD("func:%s,line:%d, time %lld", __func__, __LINE__, ALooper::GetNowUs());
			CedarXDataSourceDesc *datasrc_desc = (CedarXDataSourceDesc *)ctx->mDataSource;
			CHECK(datasrc_desc != NULL);
			pthread_mutex_lock(&datasrc_desc->m3u_handle_mutex);
			LOGD("func:%s,line:%d, time %lld", __func__, __LINE__, ALooper::GetNowUs());
			if(ctx->mLiveSession != NULL)
			{
				LOGD("func:%s,line:%d, time %lld", __func__, __LINE__, ALooper::GetNowUs());
				ctx->mLiveSession->disconnect();
				LOGD("func:%s,line:%d, time %lld", __func__, __LINE__, ALooper::GetNowUs());
				ctx->mLiveSession.clear();
				ctx->mLiveSession = NULL;
			}

			if(ctx->mLiveLooper != NULL)
			{
				LOGD("func:%s,line:%d, time %lld", __func__, __LINE__, ALooper::GetNowUs());
				ctx->mLiveLooper->stop();
				LOGD("func:%s,line:%d, time %lld", __func__, __LINE__, ALooper::GetNowUs());
				ctx->mLiveLooper.clear();
				ctx->mLiveLooper = NULL;
			}

			delete ctx;
			pthread_mutex_unlock(&datasrc_desc->m3u_handle_mutex);
		}

		int HTTPLiveSourceRead(void *ptr, size_t size, void* m3u8_context)
		{
			int 				validDataSize;
			int					sizeToRead;
			int					readBytes;
			int 				eof;
			int					tryCount;
			sp<LiveDataSource> 	source;
			m3u8_ctx_t*         ctx;

			ctx = (m3u8_ctx_t*)m3u8_context;
			if(ctx == NULL)
				return -1;

			if(ctx->mLiveSession == NULL)
				return 0;

			source = static_cast<LiveDataSource*>(ctx->mLiveSession->getDataSource().get());
			if(source == NULL)
				return 0;

			if(ctx->mForceExit)
				return 0;

			tryCount = 0;

		_read_again:
			validDataSize = source->getValidDataSize();
			eof			  = source->eof();

			if((int)size <= validDataSize)
			{
				readBytes = (int)source->readAt(0, ptr, size);
				return readBytes;
			}
			else
			{
				if(eof)
				{
					if(validDataSize <= 0)
						return 0;
					else
					{
						readBytes = (int)source->readAt(0, ptr, validDataSize);
						return readBytes;
					}
				}
				else
				{
					sizeToRead = HTTP_LIVE_TS_PACKET_SIZE * (validDataSize / HTTP_LIVE_TS_PACKET_SIZE);
					if(sizeToRead < (HTTP_LIVE_TS_PACKET_SIZE * 16))
					{
						tryCount++;
						if(tryCount >= MAX_READ_TRY_COUNT)
						{
							LOGW("!!!!!!!!!!!!!!!!!!!!: HTTPLiveSourceRead, not enough data to read, wait too long time, give up now.");
							return 0;
						}

						if(ctx->mForceExit)
							return 0;

						usleep(50*1000);
						goto _read_again;
					}

					readBytes = (int)source->readAt(0, ptr, sizeToRead);
					return readBytes;
				}
			}
		}

		int HTTPLiveSourceGetCacheState(CDX_CACHE_STATE *cdx_cache_state, void* m3u8_context)
		{
			sp<LiveDataSource> source;
			m3u8_ctx_t*        ctx;

			ctx = (m3u8_ctx_t*)m3u8_context;
			if(ctx == NULL)
				return 0;												//* Whether all data been download.

			if(ctx->mLiveSession == NULL)
			{
				cdx_cache_state->filled_size = 0;
				cdx_cache_state->eof_flag    = 0;
				return 0;
			}

			source = static_cast<LiveDataSource*>(ctx->mLiveSession->getDataSource().get());
			if(source == NULL)
			{
				cdx_cache_state->filled_size = 0;
				cdx_cache_state->eof_flag    = 0;
				return 0;
			}

			cdx_cache_state->filled_size = source->getValidDataSize();
			cdx_cache_state->eof_flag 	 = (int)source->eof();
            cdx_cache_state->filled_percent = cdx_cache_state->filled_size * 100 / (2*1024*1024);
            cdx_cache_state->bandwidth_kbps = source->getBandwidth();

//			LOGV("HTTPLiveSourceGetSize: %d, eof = %d", cdx_cache_state->filled_size, cdx_cache_state->eof_flag);

			return 0;
		}

		int64_t HTTPLiveSourceGetDuration(int64_t *duration, void* m3u8_context)
		{
			m3u8_ctx_t*         ctx;

			ctx = (m3u8_ctx_t*)m3u8_context;
			if(ctx == NULL)
				return -1;

			if (ctx->mLiveSession == NULL)
			{
				return -1;
			}

			return ctx->mLiveSession->getDuration(duration);
		}

		int64_t HTTPLiveSourceSeekTo(int64_t timeUs, void* m3u8_context)
		{
			m3u8_ctx_t*         ctx;

			ctx = (m3u8_ctx_t*)m3u8_context;
			if(ctx == NULL)
				return -1;

			if (ctx->mLiveSession == NULL)
			{
				return -1;
			}

			return ctx->mLiveSession->seekTo(timeUs);
		}

		void HTTPLiveSourceStop(CedarXDataSourceDesc *datasource_desc)
		{
			if(datasource_desc == NULL) {
				return ;
			}
			LOGD("func:%s,line:%d, datasource_desc %p, time %lld", __func__, __LINE__, datasource_desc, ALooper::GetNowUs());
			pthread_mutex_lock(&datasource_desc->m3u_handle_mutex);
			m3u8_ctx_t* ctx = (m3u8_ctx_t*)datasource_desc->m3u_handle;
			pthread_mutex_unlock(&datasource_desc->m3u_handle_mutex);
			LOGD("ctx %p", ctx);
			if(ctx == NULL || ctx->mLiveSession == NULL)
			{
				return ;
			}
			ctx->mForceExit = 1;
			ctx->mLiveSession->disconnect();
			LOGD("func:%s,line:%d, time %lld", __func__, __LINE__, ALooper::GetNowUs());
		}

	} // end extern "C"
}
