
FILE* 		awdrm_fopen(char*filename,char*mode);

int 		awdrm_fclose(FILE*fp);

int 		awdrm_ftell(FILE *fp);

long long 	awdrm_flltell(FILE *fp);

int 		awdrm_fseek(FILE*fp, long offset,int base);

int 		awdrm_fllseek(FILE*fp, long long offset,int base);

int 		awdrm_fread(char *pt, unsigned size,unsigned n,FILE *fp);

int 		awdrm_getadd(FILE*fp, char* addstream);

int 		awdrm_getaddlen(FILE*fp);

//һ����Ҫ�û���AWDRMʵ�ֵĺ����б���
extern FILE *		aw_fopen(char *filename, char *mode);

extern int 			aw_fclose(FILE *fp);

extern int 			aw_fseek(FILE *fp, long offset, int origin);

extern int 			aw_fread(void *buf, int size, int count, FILE *fp);

extern long 		aw_ftell(FILE *fp);

extern int 			aw_fwrite(void *buf, int size, int count, FILE *fp);

extern int 			aw_fllseek(FILE * fp, long long Offset, int Whence);

extern long long 	aw_flltell(FILE * stream);

FILE* 		swdrm_fopen(char*filename,char*mode);

int 		swdrm_fclose(FILE*fp);

int 		swdrm_ftell(FILE *fp);

long long 	swdrm_flltell(FILE *fp);

int 		swdrm_fseek(FILE*fp, long offset,int base);

int 		swdrm_fllseek(FILE*fp, long long offset,int base);

int 		swdrm_fread(char *pt, unsigned size,unsigned n,FILE *fp);

int 		swdrm_getadd(FILE*fp, char* addstream);

int 		swdrm_getaddlen(FILE*fp);
