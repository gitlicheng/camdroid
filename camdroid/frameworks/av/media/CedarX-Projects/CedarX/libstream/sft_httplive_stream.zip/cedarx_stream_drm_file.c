/*******************************************************************************
--                                                                            --
--                    CedarX Multimedia Framework                             --
--                                                                            --
--          the Multimedia Framework for Linux/Android System                 --
--                                                                            --
--       This software is confidential and proprietary and may be used        --
--        only as expressly authorized by a licensing agreement from          --
--                         Softwinner Products.                               --
--                                                                            --
--                   (C) COPYRIGHT 2011 SOFTWINNER PRODUCTS                   --
--                            ALL RIGHTS RESERVED                             --
--                                                                            --
--                 The entire notice above must be reproduced                 --
--                  on all copies and should not be removed.                  --
--                                                                            --
*******************************************************************************/

//#define LOG_NDEBUG 0
#define LOG_TAG "cedarx_stream_drm_file"
#include <CDX_Debug.h>

#include "cedarx_stream.h"
#include "cedarx_stream_drm_file.h"
#include <tsemaphore.h>
#include <errno.h>
#include <awdrm.h>
#include <stdio.h>

int cdx_seek_stream_drm_file(struct cdx_stream_info *stream, cdx_off_t offset, int whence)
{
	return swdrm_fseek(stream->file_handle, offset, whence);
}

cdx_off_t cdx_tell_stream_drm_file(struct cdx_stream_info *stream)
{
	return swdrm_ftell(stream->file_handle);
}

int cdx_read_stream_drm_file(void *ptr, size_t size, size_t nmemb, struct cdx_stream_info *stream)
{
	return swdrm_fread(ptr, size, nmemb, stream->file_handle);
}

long long cdx_get_stream_size_drm_file(struct cdx_stream_info *stream)
{
	long long size = -1;
	cdx_off_t curr_offset;

	if (stream->data_src_desc.stream_type == CEDARX_STREAM_NETWORK)
		return -1;

	curr_offset = swdrm_flltell(stream->file_handle);
	swdrm_fllseek(stream->file_handle, 0, SEEK_END);
	size = swdrm_flltell(stream->file_handle);
	swdrm_fllseek(stream->file_handle, curr_offset, SEEK_SET);
	return size;
}
