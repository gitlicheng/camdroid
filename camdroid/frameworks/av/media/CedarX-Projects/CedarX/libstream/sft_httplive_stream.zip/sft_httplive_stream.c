/*******************************************************************************
--                                                                            --
--                    CedarX Multimedia Framework                             --
--                                                                            --
--          the Multimedia Framework for Linux/Android System                 --
--                                                                            --
--       This software is confidential and proprietary and may be used        --
--        only as expressly authorized by a licensing agreement from          --
--                         Softwinner Products.                               --
--                                                                            --
--                   (C) COPYRIGHT 2011 SOFTWINNER PRODUCTS                   --
--                            ALL RIGHTS RESERVED                             --
--                                                                            --
--                 The entire notice above must be reproduced                 --
--                  on all copies and should not be removed.                  --
--                                                                            --
*******************************************************************************/

//#define LOG_NDEBUG 0
#define LOG_TAG "sft_httplive_stream"
#include <CDX_Debug.h>

#include <cedarx_stream.h>
#include <cedarx_demux.h>

extern int64_t HTTPLiveSourceSeekTo(int64_t timeUs, void* m3u8_context);
extern int64_t HTTPLiveSourceGetDuration(int64_t *duration, void* m3u8_context);
extern void HTTPLiveSourceStop(void* m3u8_context);

static int stream_seek(struct cdx_stream_info *stream, cdx_off_t offset, int whence)
{
	off_t pos = 0;
	LOGV("stream_seek");

	return 0;
}

static int64_t stream_seek_to_time(struct cdx_stream_info *stream, int64_t seekTimeUs)
{
	int64_t real_seektime;

	real_seektime = HTTPLiveSourceSeekTo(seekTimeUs, stream->m3u8_context);
	LOGV("HTTPLiveSourceSeekTo:%lld RealTarget:%lld",seekTimeUs,real_seektime);

	return real_seektime;
}

static int64_t stream_duration(struct cdx_stream_info *stream)
{
	int64_t durationUs = 0;
	LOGV("stream_duration");

	HTTPLiveSourceGetDuration(&durationUs, stream->m3u8_context);

	return durationUs;
}

static cdx_off_t stream_tell(struct cdx_stream_info *stream)
{
	LOGV("stream_tell");
	//return stream_tell();
	return 0;
}

static int stream_read(void *ptr, size_t size, size_t nmemb, struct cdx_stream_info *stream)
{
	LOGV("stream_read");
	if(size >= 0) {
		return HTTPLiveSourceRead(ptr, size*nmemb, stream->m3u8_context)/size;
	} else {
		return -1;
	}
}

static void stream_reset(struct cdx_stream_info *stream)
{
	return ;
}

static int stream_control(struct cdx_stream_info *stream, void *arg, int cmd)
{
	CDX_CACHE_STATE* cdx_cache_state ;

	switch (cmd)
	{
	case CDX_DMX_CMD_GET_CACHE_STATE:
		cdx_cache_state = (CDX_CACHE_STATE *)arg;
		HTTPLiveSourceGetCacheState(arg, stream->m3u8_context);
		LOGV("filled_size: %d", cdx_cache_state->filled_size);
		break;

	case CDX_STREAM_CMD_FORCE_EXIT:
		HTTPLiveSourceStop(stream->m3u8_context);
		break;

	default:
		break;
	}

	return 0;
}

int sft_httplive_create_stream_handle(CedarXDataSourceDesc *datasource_desc, struct cdx_stream_info *stm_info)
{
	LOGV("HTTPLiveSourceOpen url: %s", datasource_desc->source_url);

	stm_info->m3u8_context = HTTPLiveSourceOpen(datasource_desc);
	if(stm_info->m3u8_context == NULL)
		return 0;
	pthread_mutex_init(&datasource_desc->m3u_handle_mutex, NULL);
	stm_info->another_data_src_desc = datasource_desc;

	stm_info->seek               = stream_seek;
	stm_info->tell               = stream_tell;
	stm_info->read               = stream_read;
	stm_info->seek_to_time       = stream_seek_to_time;
	stm_info->get_total_duration = stream_duration;
	stm_info->reset_stream       = stream_reset;
	stm_info->control_stream     = stream_control;
	stm_info->write = NULL;
    stm_info->getsize = NULL;

	return 0;
}

void sft_httplive_destory_stream_handle(struct cdx_stream_info *stm_info)
{
	if(!stm_info) {
		return ;
	}
	CedarXDataSourceDesc *datasource_desc = stm_info->another_data_src_desc;
	LOGV("func:%s,line:%d, datasource_desc %p", __func__, __LINE__, datasource_desc);
	HTTPLiveSourceClose(stm_info->m3u8_context);
	pthread_mutex_destroy(&datasource_desc->m3u_handle_mutex);
}

void sft_httplive_force_stop(void * handle)
{
	LOGV("sft_httplive_force_stop, handle %p", handle);
	HTTPLiveSourceStop(handle);
}

