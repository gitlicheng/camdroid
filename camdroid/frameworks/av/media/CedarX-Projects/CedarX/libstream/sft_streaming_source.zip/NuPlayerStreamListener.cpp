/*
 * Copyright (C) 2010 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <CDX_LogNDebug.h>
#define LOG_TAG "NuPlayerStreamListener"
#include <CDX_Debug.h>

#include "NuPlayerStreamListener.h"

#include <binder/MemoryDealer.h>
#include <media/stagefright/foundation/ADebug.h>
#include <media/stagefright/foundation/AMessage.h>
#include <media/stagefright/foundation/hexdump.h>
#include <media/stagefright/MediaErrors.h>

//#define __SAVE_TS_STREAM_TO_FILE

namespace android {
#ifdef __SAVE_TS_STREAM_TO_FILE
FILE *fp = NULL;
static int fnum = 0;
#endif
NuPlayerStreamListener::NuPlayerStreamListener(const sp<IStreamSource> &source,ALooper::handler_id id)
    : mSource(source),
      mTargetID(id),
      mEOS(false),
      mSendDataNotification(true),
      mAvailableSize(0)
{
    mSource->setListener(this);

    mNumBuffers = kNumBuffers;
    mBufferSize = kBufferSize;

    mMemoryDealer = new MemoryDealer(mNumBuffers * mBufferSize);
    for (int i = 0; i < mNumBuffers; ++i)
    {
        sp<IMemory> mem = mMemoryDealer->allocate(mBufferSize);
        CHECK(mem != NULL);

        mBuffers.push(mem);
    }

    mSource->setBuffers(mBuffers);
}

NuPlayerStreamListener::NuPlayerStreamListener(const sp<IStreamSource> &source,ALooper::handler_id id,
		                                       int numBuffers, int bufferSize)
    : mSource(source),
      mTargetID(id),
      mEOS(false),
      mSendDataNotification(true),
      mAvailableSize(0)
{
    mSource->setListener(this);

    mNumBuffers = numBuffers;
    mBufferSize = bufferSize;

    mMemoryDealer = new MemoryDealer(mNumBuffers * mBufferSize);
    for (int i = 0; i < mNumBuffers; ++i)
    {
        sp<IMemory> mem = mMemoryDealer->allocate(mBufferSize);
        CHECK(mem != NULL);

        mBuffers.push(mem);
    }

    mSource->setBuffers(mBuffers);
}

void NuPlayerStreamListener::start()
{
	LOGV("NuPlayerStreamListener::start");
#ifdef __SAVE_TS_STREAM_TO_FILE
	char path[64];
	if(fp != NULL) {
		fclose(fp);
		fp = NULL;
	}
	sprintf(path,"/data/camera/nu_%d.awts",fnum);
	fp = fopen(path,"wb");
	LOGW("write to file: %s",path);
	fnum++;
#endif
    for (int i = 0; i < mNumBuffers; ++i)
    {
    	if(mEOS) {
    		break;
    	}
        mSource->onBufferAvailable(i);
    }
}

void NuPlayerStreamListener::stop()
{
	//If not set listener as NULL,
	//BnStreamSource has a ref of this handle,
	//while this handle has a ref of BnStreamSource.
	//This is a dead loop which causes memeroy leak.
#ifdef __SAVE_TS_STREAM_TO_FILE
	if(fp) {
		fclose(fp);
		fp = NULL;
	}
#endif
	mEOS = true;
	mSource->setListener(NULL);
}

void NuPlayerStreamListener::queueBuffer(size_t index, size_t size)
{
    //LOGV("NuPlayerStreamListener::queueBuffer, size %d, index %d", size, index);
    Mutex::Autolock autoLock(mLock);
    QueueEntry entry;
    entry.mIsCommand = false;
    entry.mIndex = index;
    entry.mSize = size;
    entry.mOffset = 0;

    mAvailableSize += size;

    mQueue.push_back(entry);

//    if (mSendDataNotification) {
//        mSendDataNotification = false;
//
//        if (mTargetID != 0) {
//            (new AMessage(kWhatMoreDataQueued, mTargetID))->post();
//        }
//    }
}
void NuPlayerStreamListener::clearBuffer() {
	Mutex::Autolock autoLock(mLock);

	LOGV("queue size %d", mQueue.size());
	QueueEntry *entry = NULL;
    while(mQueue.size() > 0 && !mEOS) {
    	entry = &*mQueue.begin();
    	CHECK(entry != NULL);
        mSource->onBufferAvailable(entry->mIndex);
        mQueue.erase(mQueue.begin());
        entry = NULL;
    }
    mAvailableSize = 0;
	CHECK(mQueue.empty() || mEOS);
}

void NuPlayerStreamListener::issueCommand(
        Command cmd, bool synchronous, const sp<AMessage> &extra) {
    CHECK(!synchronous);
    LOGV("NuPlayerStreamListener::issueCommand");
    Mutex::Autolock autoLock(mLock);
    QueueEntry entry;
    entry.mIsCommand = true;
    entry.mCommand = cmd;
    entry.mExtra = extra;
    mQueue.push_back(entry);
    if(entry.mCommand == EOS) {
    	mEOS = true;
    }

//    if (mSendDataNotification) {
//        mSendDataNotification = false;
//
//        if (mTargetID != 0) {
//            (new AMessage(kWhatMoreDataQueued, mTargetID))->post();
//        }
//    }
}

ssize_t NuPlayerStreamListener::read(
        void *data, size_t size, sp<AMessage> *extra) {
    CHECK_GT(size, 0u);
    extra->clear();
    Mutex::Autolock autoLock(mLock);
    if (mEOS) {
        return -ENODATA;
    }

    if (mQueue.empty() || mAvailableSize < size) {
        mSendDataNotification = true;
        return -EAGAIN;
    }

    size_t copiedSize = 0;
    while(copiedSize < size) {

    	if(mQueue.empty()) {
    		//Should not be here.
    		LOGW("Have not gotten enough data, but queue is empty. %d vs %d",
    				mAvailableSize, size);
    		break;
    	}

		QueueEntry *entry = &*mQueue.begin();
		if (entry->mIsCommand) {
			LOGV("NuPlayerStreamListener mCommand:%d",entry->mCommand);
			switch (entry->mCommand) {
				case EOS:
				{
					mQueue.erase(mQueue.begin());
					entry = NULL;
					mEOS = true;
					return -ENODATA;
				}

				case DISCONTINUITY:
				{
					*extra = entry->mExtra;
					mQueue.erase(mQueue.begin());
					entry = NULL;
					return INFO_DISCONTINUITY;
				}

				default:
					TRESPASS();
					break;
			}
		}

		size_t copy = entry->mSize;
		if (copy > size) {
			copy = size;
		}

		memcpy((uint8_t *)data + copiedSize,
			   (const uint8_t *)mBuffers.editItemAt(entry->mIndex)->pointer()
				+ entry->mOffset,
			   copy);
	#ifdef __SAVE_TS_STREAM_TO_FILE
		if(fp) {
			fwrite(data,1,copy,fp);
		}
	#endif
		entry->mOffset 	+= copy;
		entry->mSize 	-= copy;
		mAvailableSize 	-= copy;
		copiedSize 		+= copy;
		if (entry->mSize == 0) {
			mSource->onBufferAvailable(entry->mIndex);
			mQueue.erase(mQueue.begin());
			entry = NULL;
		}
	}
    return copiedSize;
}

}  // namespace android
