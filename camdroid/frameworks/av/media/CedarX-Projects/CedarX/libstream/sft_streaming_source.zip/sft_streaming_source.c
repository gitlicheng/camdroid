/*******************************************************************************
--                                                                            --
--                    CedarX Multimedia Framework                             --
--                                                                            --
--          the Multimedia Framework for Linux/Android System                 --
--                                                                            --
--       This software is confidential and proprietary and may be used        --
--        only as expressly authorized by a licensing agreement from          --
--                         Softwinner Products.                               --
--                                                                            --
--                   (C) COPYRIGHT 2011 SOFTWINNER PRODUCTS                   --
--                            ALL RIGHTS RESERVED                             --
--                                                                            --
--                 The entire notice above must be reproduced                 --
--                  on all copies and should not be removed.                  --
--                                                                            --
*******************************************************************************/

//#define LOG_NDEBUG 0
#define LOG_TAG "sft_streaming_source"
#include <CDX_Debug.h>

#include <cedarx_stream.h>
#include <cedarx_demux.h>

extern void StreamingSourceOpen(void* handle, int numBuffer, int bufferSize);
extern void StreamingSourceClose(void* handle);
extern int StreamingSourceRead(void* handle, void *ptr, size_t size);
extern int StreamingSourceGetCacheState(CDX_CACHE_STATE *cdx_cache_state);
extern void StreamingSourceClearBuffer(void* handle, void *para);

static int stream_seek(struct cdx_stream_info *stream, cdx_off_t offset, int whence)
{
	off_t pos = 0;
	LOGV("stream_seek");

	return 555;
}

static int64_t stream_seek_to_time(struct cdx_stream_info *stream, int64_t seekTimeUs)
{
	int64_t real_seektime = 0;

	//real_seektime = StreamingSourceSeekTo(seekTimeUs);
	LOGV("StreamingSourceSeekTo:%lld RealTarget:%lld",seekTimeUs,real_seektime);

	return real_seektime;
}

static int64_t stream_duration(struct cdx_stream_info *stream)
{
	int64_t durationUs = 0;
	LOGV("stream_duration");

	//StreamingSourceGetDuration(&durationUs);

	return durationUs;
}

static cdx_off_t stream_tell(struct cdx_stream_info *stream)
{
	LOGV("stream_tell");
	//return stream_tell();
	return 0;
}

static int stream_read(void *ptr, size_t size, size_t nmemb, struct cdx_stream_info *stream)
{
	LOGV("stream_read");
	return StreamingSourceRead(stream->reserved_1, ptr, size*nmemb);
}

static void stream_reset(struct cdx_stream_info *stream)
{
	return ;
}

static int stream_control(struct cdx_stream_info *stream, void *arg, int cmd)
{
	CDX_CACHE_STATE *cdx_cache_state = (CDX_CACHE_STATE *)arg;

	switch (cmd) {
	case CDX_DMX_CMD_GET_CACHE_STATE:
		StreamingSourceGetCacheState(arg);
		LOGV("filled_size: %d", cdx_cache_state->filled_size);
		break;

	case CDX_DMX_CMD_CLEAR_BUFFER:
		StreamingSourceClearBuffer(stream->reserved_1, arg);
		break;

	default:
		break;
	}

	return 0;
}

static long long stream_getsize(struct cdx_stream_info *stream)
{
	return 0;
}

int sft_streaming_create_stream_handle(CedarXDataSourceDesc *datasource_desc, struct cdx_stream_info *stm_info)
{
	int numBuffer;
	int bufferSize;

	if(datasource_desc->demux_type == CDX_MEDIA_FILE_FMT_TS)
	{
		numBuffer  = 512;
		bufferSize = 64*188;
	}
	else
	{
		numBuffer  = 16;
		bufferSize = 4*1024;
	}

	StreamingSourceOpen(datasource_desc->sft_stream_handle, numBuffer, bufferSize);
	stm_info->reserved_1         = datasource_desc->sft_stream_handle;

	stm_info->seek               = stream_seek;
	stm_info->tell               = stream_tell;
	stm_info->read               = stream_read;
	stm_info->seek_to_time       = stream_seek_to_time;
	stm_info->get_total_duration = stream_duration;
	stm_info->reset_stream       = stream_reset;
	stm_info->control_stream     = stream_control;
	stm_info->write = NULL;
    stm_info->getsize = stream_getsize;

	return 0;
}

void sft_streaming_destory_stream_handle(struct cdx_stream_info *stm_info)
{
	StreamingSourceClose(stm_info->reserved_1);
}

