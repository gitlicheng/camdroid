/*
 * Copyright (C) 2010 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <CDX_LogNDebug.h>
#define LOG_TAG "StreamingSource"
#include <CDX_Debug.h>

#include "StreamingSource.h"

//#include "ATSParser.h"
//#include "AnotherPacketSource.h"
#include "NuPlayerStreamListener.h"

#include <media/stagefright/foundation/ABuffer.h>
#include <media/stagefright/foundation/ADebug.h>
#include <media/stagefright/foundation/AMessage.h>
#include <media/stagefright/MediaSource.h>
#include <media/stagefright/MetaData.h>

#include <CDX_GlobalParaDef.h>
#include <cedarx_demux.h>

namespace android {

StreamingSource::StreamingSource(const sp<IStreamSource> &source)
    : mSource(source),
      mFinalResult(OK) {
	LOGV("StreamingSource Constructor");
}

StreamingSource::~StreamingSource() {
	LOGV("StreamingSource Constructor ~De");
}

void StreamingSource::start(int numBuffer, int bufferSize)
{
    mStreamListener = new NuPlayerStreamListener(mSource, 0, numBuffer, bufferSize);

    mStreamListener->start();
}

void StreamingSource::stop()
{
    mStreamListener->stop();
}

void StreamingSource::clearBuffer()
{
    mStreamListener->clearBuffer();
}

int StreamingSource::dequeueAccessData(char *accessData, int size)
{
	sp<AMessage> extra;
	ssize_t n;

	n = mStreamListener->read(accessData, size , &extra);
	if (n == 0) {
		LOGI("input data EOS reached.");
		mFinalResult = ERROR_END_OF_STREAM;
	} else if (n == INFO_DISCONTINUITY) {
		int32_t type = ATSParser::DISCONTINUITY_SEEK;

		int32_t mask;
		if (extra != NULL
				&& extra->findInt32(
					IStreamListener::kKeyDiscontinuityMask, &mask)) {
			if (mask == 0) {
				LOGE("Client specified an illegal discontinuity type.");
				return ERROR_UNSUPPORTED;
			}

			type = mask;
		}
	}
//	LOGV("read size %ld, require size %d", n, size);
	return n;
}

extern "C" {

//#define __DEBUG_OUTPUT_STREAM

#ifdef __DEBUG_OUTPUT_STREAM
static FILE *fp_ts;
static int fp_num = 0;
#endif

void StreamingSourceOpen(void* handle, int numBuffer, int bufferSize)
{
#if 0
	sp<StreamingSource> mStreamingSource;
	sp<RefBase> obj = (RefBase *)handle;
	mStreamingSource = static_cast<StreamingSource *>(obj.get());
#else
	sp<StreamingSource> mStreamingSource = static_cast<StreamingSource *>(handle);
#endif

#ifdef __DEBUG_OUTPUT_STREAM
	char fpath[64];
	sprintf(fpath,"/data/camera/dbg%d.ts",fp_num);
	LOGD("fpath:%s",fpath);
	fp_ts = fopen(fpath,"wb");
#endif

	mStreamingSource->start(numBuffer, bufferSize);
}

void StreamingSourceClose(void* handle)
{
	sp<StreamingSource> mStreamingSource = static_cast<StreamingSource *>(handle);
	if(mStreamingSource.get()) {
		mStreamingSource->stop();
	}
#ifdef __DEBUG_OUTPUT_STREAM
	fclose(fp_ts);
#endif
}

int StreamingSourceRead(void* handle, void *ptr, size_t size)
{
#if 0
	sp<StreamingSource> mStreamingSource;
	sp<RefBase> obj = (RefBase *)handle;
	mStreamingSource = static_cast<StreamingSource *>(obj.get());
#else
	sp<StreamingSource> mStreamingSource = static_cast<StreamingSource *>(handle);
#endif

	int tmp;
	tmp = mStreamingSource->dequeueAccessData((char*)ptr, size);
#ifdef __DEBUG_OUTPUT_STREAM
	if(fp_ts != NULL)
	{
		fwrite(ptr, 1, tmp, fp_ts);
		LOGD("write %d bytes", size);
	}
#endif

	return tmp;
}

void StreamingSourceClearBuffer(void* handle, void *para) {
	sp<StreamingSource> mStreamingSource = static_cast<StreamingSource *>(handle);
	if(mStreamingSource != NULL) {
		mStreamingSource->clearBuffer();
	}
}

int StreamingSourceGetCacheState(CDX_CACHE_STATE *cdx_cache_state)
{
//	cdx_cache_state->filled_size = gStreamingSource->pkt_count * TS_TINY_PACKET_SIZE;
//	cdx_cache_state->eof_flag = gStreamingSource->eof;
//	LOGV("get cache state filled_size:%d eof:%d", cdx_cache_state->filled_size,gStreamingSource->eof);

	return 0;
}

} //extern "C"

}  // namespace android

