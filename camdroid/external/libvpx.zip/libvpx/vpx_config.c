static const char* const cfg = "--target=generic-gnu";
const char *vpx_codec_build_config(void) {return cfg;}
