#ifndef __SH7722__SCREEN_H__
#define __SH7722__SCREEN_H__

#include <core/screens.h>

extern ScreenFuncs sh7722ScreenFuncs;

#endif

